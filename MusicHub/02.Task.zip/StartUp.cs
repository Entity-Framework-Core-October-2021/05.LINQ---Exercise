﻿namespace MusicHub
{
    using System;
    using System.Globalization;
    using System.Linq;
    using System.Text;
    using Data;
    using Initializer;

    public class StartUp
    {
        public static void Main(string[] args)
        {
            MusicHubDbContext context =
                new MusicHubDbContext();

            DbInitializer.ResetDatabase(context);

            //Test your solutions here
            string result = ExportAlbumsInfo(context, 9);
            Console.WriteLine(result);
        }

        public static string ExportAlbumsInfo(MusicHubDbContext context, int producerId)
        {
            StringBuilder sb = new StringBuilder();

            var albumsInfo = context.Albums
                                    .ToArray()
                                    .Where(a => a.ProducerId == producerId)
                                    .OrderByDescending(a => a.Price)
                                    .Select(a => new
                                    {
                                        AlbumName = a.Name,
                                        ReleaseDate = a.ReleaseDate.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture),
                                        ProducerName = a.Producer.Name,
                                        Songs = a.Songs
                                                 .ToArray()
                                                 .Select(s => new
                                                 {
                                                     SongName = s.Name,
                                                     Price = s.Price.ToString("f2"),
                                                     Writer = s.Writer.Name
                                                 })
                                                 .OrderByDescending(s => s.SongName)
                                                 .ThenBy(s => s.Writer)
                                                 .ToArray(),
                                        TotalAlbumPrice = a.Price.ToString("f2")
                                    })
                                    .ToArray();

            foreach (var album in albumsInfo)
            {
                sb.Append($"-AlbumName: {album.AlbumName}\r\n")
                  .Append($"-ReleaseDate: {album.ReleaseDate}\r\n")
                  .Append($"-ProducerName: {album.ProducerName}\r\n")
                  .Append($"-Songs:\r\n");

                int i = 1;
                foreach (var song in album.Songs)
                {
                    sb.Append($"---#{i++}\r\n")
                      .Append($"---SongName: {song.SongName}\r\n")
                      .Append($"---Price: {song.Price}\r\n")
                      .Append($"---Writer: {song.Writer}\r\n");
                }

                sb.Append($"-AlbumPrice: {album.TotalAlbumPrice}\r\n");
            };

            return sb.ToString().TrimEnd();
        }

        public static string ExportSongsAboveDuration(MusicHubDbContext context, int duration)
        {
            throw new NotImplementedException();
        }
    }
}
